console.log('funcionando');

function enviarForm() {
    alert('Tu datos de contacto han sido registrados con exito');
}

$.get({
    url: './assets/js/discos.json',
    dataType: 'json',

    success: function(respuesta){ // Respuesta correcta en caso que el recurso si exista, si lo encuentra
        console.log(respuesta)

        let divDisco; // La variable que vamos a contruir

        let discos; // Guarda los datos discos
        discos = respuesta.discos; // array discos

        $.each(respuesta.discos, function(index,item){

            // Cartas que se muestran en el index
            divDisco = '<div class="col-md-3 mb-4 p-3">';
                divDisco += '<div class="text-center">';
                    divDisco += '<img src="' + item.disco.cover + '" class="w-100 shadow mb-3" alt"Imagen del Disco">';
                    divDisco += '<div class="d-flex justify-content-center">';
                        divDisco += '<div class="d-flex flex-column">';
                            // Botón del modal
                            divDisco += '<div class="d-flex justify-content-center btn mb-2"'
                                divDisco += '<button type="button" data-bs-toggle="modal" data-bs-target="#discoModal" data-disco="' + index + '">' + '<strong>' + item.disco.titulo + '</strong>' + '</button>';
                            divDisco += '</div>'
                            divDisco += '<div class="text-start">'
                                divDisco += item.disco.descripcion;
                            divDisco += '</div>'
                        divDisco += '</div>'
                    divDisco += '</div>';
                divDisco += '</div>';
            divDisco += '</div>'
            
            $('#datosDisco').append(divDisco);
        });

        // Modal
        let elModal = document.getElementById('discoModal');
        elModal.addEventListener('shown.bs.modal', function(event) {
            let button = event.relatedTarget; // El relatedTarget se supone que reconoce el botón del modal
        
            let datosDisco = button.getAttribute('data-disco'); // Obtiene lo que se gurdó en el botón data-disco
            
            let elDisco = discos[datosDisco].disco; // Obtiene el disco seleccionado

            /* 
            // Datos del Modal con js nativo
            document.getElementById('tituloModal').textContent = elDisco.titulo;
            document.getElementById('datosAño').textContent = elDisco.año;
            document.getElementById('datosCover').innerHTML = '<img src="' + elDisco.Cover + '" class="img-fluid shadow img-modal">';
            document.getElementById('datosDescripcion').textContent = elDisco.descripcion;
            document.getElementById('datosDescripcion-e').textContent = elDisco.descripcionE;
            document.getElementById('datosInfluencias').textContent = elDisco.influencias;
            */

            // Datos del Modal con jquery
            $('#tituloModal').text(elDisco.titulo);
            $('#datosAño').text(elDisco.año);
            $('#datosCover').html('<img src="' + (elDisco.cover) + '" class="img-fluid shadow img-modal">');
            $('#datosDescripcion').text(elDisco.descripcion);
            $('#datosDescripcion-e').text(elDisco.descripcionE);
            $('#datosInfluencias').text(elDisco.influencias);
            $('#datosLink').text(elDisco.link);
            $('#datosCanciones').html('<ol>' + elDisco.canciones.join('') + '</ol>'); // el join es para que se una toda la cadena sin las comas al pasarle una cadena vacía('')
        }); 
    },

    // Respuesta errónea en caso que el recurso no exista, si no lo encuentra
    error: function(error){
        console.log('Error al cargar los datos del disco');
        console.log(error);
    },
});

